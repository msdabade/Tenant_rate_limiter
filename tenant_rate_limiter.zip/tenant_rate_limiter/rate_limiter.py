import time
import threading
from collections import deque, defaultdict
from pydantic import BaseModel

class CheckAndConsumeRequest(BaseModel):
    tenant_id: str
    client_id: str
    action_type: str
    max_requests: int
    window_duration_seconds: int

all_logs = defaultdict(deque)
all_locks = defaultdict(threading.Lock)

def make_key(tenant, client, action):
    return f"{tenant}:{client}:{action}"

def remove_old_times(log, window, now):
    while log and log[0] <= now - window:
        log.popleft()

def check_and_add(tenant, client, action, max_req, window_sec):
    key = make_key(tenant, client, action)
    now = time.time()
    lock = all_locks[key]
    with lock:
        log = all_logs[key]
        remove_old_times(log, window_sec, now)
        if len(log) < max_req:
            log.append(now)
            left = max_req - len(log)
            reset = int(now + window_sec)
            return True, left, reset
        else:
            if log:
                reset = int(log[0] + window_sec)
            else:
                reset = int(now + window_sec)
            return False, 0, reset 