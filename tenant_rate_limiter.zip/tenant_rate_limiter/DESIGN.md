# DESIGN.md

## System Architecture
- FastAPI web service
- 3 parts: Rate Limiter, Load Manager, API Layer
- Each tenant tracked separately

## Data Structures & Algorithms
- `deque` for (tenant, client, action) timestamps
- `deque` for each tenant queue
- Sliding window log: remove old, add new, check length
- `defaultdict` for easy per-tenant/client/action

## Concurrency Model
- `threading.Lock` for each log/queue
- Locks for global and per-tenant inflight counters
- Per-tenant locks = no blocking between tenants

## API Design
- `POST /check_and_consume`: check + consume, returns status
- `GET /status/{tenant_id}/{client_id}/{action_type}`: debug info
- `status` field: processed, rate_limited, queued, rejected
- JSON for all requests/responses

## Error Handling Strategy
- Queue full: status = "rejected"
- Server busy: status = "queued"
- Server error: 500 + error message
- All errors as JSON

## Scalability Considerations
- In-memory = single server only
- For scale: Redis for logs/queues, Redlock for locks, Kafka for queues
- Per-tenant data = easy to split
- Challenges: sync inflight/queues, noisy neighbor, cross-server rate limit
- Solutions: central service, sticky sessions, service mesh

## Trade-offs
- Fast but more memory (many tenants/clients)
- Sliding window = accurate, more complex
- Per-tenant locks/queues = isolation, more resources
- FIFO queue: heavy tenants may wait

## Testing Strategy
- Unit tests: rate limiter, load manager (`test_unit.py`)
- Concurrency: simulate many requests
- Multi-tenant: one tenant floods, others checked
