
This project implements a standalone, in-memory service for multi-tenant aware rate limiting and tenant-level load management. It is designed for extensibility and scalability in distributed environments.

## Features
- **Sliding Window Log Rate Limiting** per (tenant_id, client_id, action_type)
- **Tenant-Level Load Management** with per-tenant queues and global/tenant thresholds
- **API Endpoints** for checking/consuming tokens and querying status
- **Thread-safe** in-memory implementation
- **Extensible** for distributed and production use

## API Endpoints

### POST `/check_and_consume`
Checks and consumes a rate limit token for a given tenant, client, and action.

**Request Body:**
```
{
  "tenant_id": "org_a_123",
  "client_id": "user123",
  "action_type": "api_call",
  "max_requests": 10,
  "window_duration_seconds": 60
}
```

**Response Body:**
```
{
  "allowed": true,
  "remaining_requests": 5,
  "reset_time_seconds": 1678886400,
  "status": "processed" // or "queued" or "rejected"
}
```

### GET `/status/{tenant_id}/{client_id}/{action_type}`
Returns the current state of the rate limit for debugging.

## Running the Service

1. Create and Activate a Virtual Environment (Optional but Recommended) 

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Start the server:
   ```bash
   uvicorn main:app --reload
   ```
3. The API will be available at `http://localhost:8000`.

