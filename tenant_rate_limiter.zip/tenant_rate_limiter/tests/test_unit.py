import unittest
import time
from rate_limiter import check_and_add, CheckAndConsumeRequest, all_logs
from load_manager import can_do, add_to_queue, tenant_count, tenant_queue, MAX_QUEUE

class DummyBG:
    def add_task(self, *args, **kwargs):
        pass

class TestSimple(unittest.TestCase):
    def setUp(self):
        all_logs.clear()
        tenant_count.clear()
        tenant_queue.clear()

    def test_rate_limit(self):
        ok, left, _ = check_and_add('t', 'c', 'a', 2, 1)
        self.assertTrue(ok)
        ok, left, _ = check_and_add('t', 'c', 'a', 2, 1)
        self.assertTrue(ok)
        ok, left, _ = check_and_add('t', 'c', 'a', 2, 1)
        self.assertFalse(ok)
        time.sleep(1)
        ok, left, _ = check_and_add('t', 'c', 'a', 2, 1)
        self.assertTrue(ok)

    def test_can_do(self):
        self.assertTrue(can_do('t'))
        tenant_count['t'] = 9999  
        self.assertFalse(can_do('t'))

    def test_queue(self):
        req = CheckAndConsumeRequest(
            tenant_id='t',
            client_id='c',
            action_type='a',
            max_requests=1,
            window_duration_seconds=1
        )
        bg = DummyBG()
        for _ in range(MAX_QUEUE):
            self.assertTrue(add_to_queue('t', req, bg))
        self.assertFalse(add_to_queue('t', req, bg))

if __name__ == "__main__":
    unittest.main() 