from fastapi import FastAPI, Request, BackgroundTasks
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional
from rate_limiter import CheckAndConsumeRequest, check_and_add, all_logs, all_locks, make_key
from load_manager import can_do, add_inflight, sub_inflight, add_to_queue, do_queue, tenant_count, tenant_queue
import time

app = FastAPI()

class CheckAndConsumeResponse(BaseModel):
    allowed: bool
    remaining_requests: int
    reset_time_seconds: Optional[int] = None
    status: str

@app.post("/check_and_consume", response_model=CheckAndConsumeResponse)
def check_and_consume(req: CheckAndConsumeRequest, background_tasks: BackgroundTasks):
    tenant = req.tenant_id
    if can_do(tenant):
        add_inflight(tenant)
        try:
            allowed, left, reset = check_and_add(
                req.tenant_id, req.client_id, req.action_type, req.max_requests, req.window_duration_seconds
            )
            if allowed:
                status = "processed"
            else:
                status = "rate_limited"
            return CheckAndConsumeResponse(
                allowed=allowed,
                remaining_requests=left,
                reset_time_seconds=reset,
                status=status
            )
        finally:
            sub_inflight(tenant)
            do_queue(tenant)
    else:
        queued = add_to_queue(tenant, req, background_tasks)
        if queued:
            status = "queued"
            return CheckAndConsumeResponse(
                allowed=False,
                remaining_requests=0,
                reset_time_seconds=None,
                status=status
            )
        else:
            status = "rejected"
            return CheckAndConsumeResponse(
                allowed=False,
                remaining_requests=0,
                reset_time_seconds=None,
                status=status
            )

@app.get("/status/{tenant_id}/{client_id}/{action_type}")
def get_status(tenant_id: str, client_id: str, action_type: str):
    key = make_key(tenant_id, client_id, action_type)
    lock = all_locks[key]
    with lock:
        log = list(all_logs[key])
    now = time.time()
    windowed = [ts for ts in log if ts > now - 60]
    queue_len = len(tenant_queue[tenant_id])
    inflight = tenant_count[tenant_id]
    return {
        "timestamps": log,
        "current_count": len(windowed),
        "queue_length": queue_len,
        "inflight": inflight
    }

@app.exception_handler(Exception)
def generic_exception_handler(request: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"detail": str(exc)})
