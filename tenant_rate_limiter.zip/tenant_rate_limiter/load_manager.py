import threading
from collections import deque, defaultdict
from rate_limiter import check_and_add

MAX_GLOBAL = 100
MAX_TENANT = 20
MAX_QUEUE = 50

global_lock = threading.Lock()
global_count = 0
tenant_count = defaultdict(int)
tenant_lock = defaultdict(threading.Lock)
tenant_queue = defaultdict(deque)
tenant_queue_lock = defaultdict(threading.Lock)

def can_do(tenant):
    with global_lock:
        if global_count >= MAX_GLOBAL:
            return False
    with tenant_lock[tenant]:
        if tenant_count[tenant] >= MAX_TENANT:
            return False
    return True

def add_inflight(tenant):
    global global_count
    with global_lock:
        global_count += 1
    with tenant_lock[tenant]:
        tenant_count[tenant] += 1

def sub_inflight(tenant):
    global global_count
    with global_lock:
        global_count -= 1
    with tenant_lock[tenant]:
        tenant_count[tenant] -= 1

def add_to_queue(tenant, req, bg):
    with tenant_queue_lock[tenant]:
        q = tenant_queue[tenant]
        if len(q) >= MAX_QUEUE:
            return False
        q.append((req, bg))
    return True

def do_queue(tenant):
    with tenant_queue_lock[tenant]:
        q = tenant_queue[tenant]
        while q:
            if not can_do(tenant):
                break
            req, bg = q.popleft()
            bg.add_task(do_req, req, bg, True)

def do_req(req, bg, from_queue=False):
    tenant = req.tenant_id
    add_inflight(tenant)
    try:
        allowed, left, reset = check_and_add(
            req.tenant_id, req.client_id, req.action_type, req.max_requests, req.window_duration_seconds
        )
    finally:
        sub_inflight(tenant)
        do_queue(tenant) 